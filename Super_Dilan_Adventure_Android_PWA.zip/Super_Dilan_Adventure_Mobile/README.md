# Super Dilan Adventure — Android / PWA

Versión móvil del plataformas 2D. Usa HTML5 Canvas y JavaScript, sin librerías externas.

## Incluye
- Controles táctiles de izquierda, derecha y salto.
- Doble salto, monedas, estrellas y bloques secretos.
- Enemigos patrulleros y jefes con puntos de vida.
- Tres vidas, checkpoints, 5 mundos y 10 niveles.
- Selección de niveles y progreso guardado en el dispositivo.
- Música/efectos retro generados con Web Audio.
- PWA: manifiesto y service worker para instalación y caché offline.

## Cómo jugar en Android
1. Publica todos los archivos de esta carpeta en un sitio con HTTPS (por ejemplo, GitHub Pages).
2. Abre el enlace publicado en Chrome en tu Android.
3. Gira el celular a horizontal.
4. En Chrome, abre el menú ⋮ y elige **Instalar aplicación** o **Añadir a pantalla de inicio**.
5. Abre el icono de Super Dilan Adventure.

> Importante: por seguridad, Android/Chrome no instala una PWA directamente desde un archivo ZIP o `file://`. Necesita una dirección HTTPS. Una vez instalada y cargada por primera vez, los archivos del juego quedan disponibles mediante caché para jugar sin conexión.

## Publicar con GitHub Pages
1. Crea un repositorio nuevo en GitHub.
2. Sube el contenido de esta carpeta a la raíz del repositorio.
3. En Settings → Pages, elige Deploy from a branch, selecciona `main` y `/ (root)`.
4. Espera a que GitHub muestre el enlace HTTPS y ábrelo en Chrome.

## Controles
- ◀ / ▶: moverse.
- SALTO: saltar; tocar de nuevo en el aire hace doble salto.
- Ⅱ: pausa.
- Toca los niveles desbloqueados en la selección.

## Archivos
- `index.html`: pantalla y controles.
- `style.css`: diseño adaptable y botones táctiles.
- `game.js`: lógica del juego, niveles, colisiones y dibujo pixel art.
- `manifest.webmanifest`: configuración instalable.
- `sw.js`: caché offline.
- `icon.svg`: icono de la aplicación.

Todos los personajes, gráficos y sonidos son originales y generados por código.
