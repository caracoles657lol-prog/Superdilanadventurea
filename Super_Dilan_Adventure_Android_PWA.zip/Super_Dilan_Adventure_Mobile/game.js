(() => {
"use strict";
const canvas=document.getElementById("game"),ctx=canvas.getContext("2d");
const W=960,H=540,GROUND=450,LEVELS=10,WORLDS=["Reino Verde","Desierto Perdido","Reino Helado","Castillo Oscuro","Mundo Final"];
const skies=["#70c9f4","#f5c27d","#b9e5f2","#34304f","#201b3e"];
const grounds=["#4caa65","#c18a4c","#a7d7e5","#655675","#65558c"];
const accents=["#267548","#8e5d31","#5e9cb6","#ad5266","#e28a58"];
let state="menu",levelIndex=0,level,player,camera=0,lives=3,score=0,coins=0,unlocked=Number(localStorage.getItem("sdaUnlocked")||0),toastTimer=0,lastJump=false,muted=false,audioCtx=null;
const keys={left:false,right:false,jump:false};
function resize(){const dpr=Math.min(devicePixelRatio||1,2);canvas.width=Math.round(innerWidth*dpr);canvas.height=Math.round(innerHeight*dpr);ctx.setTransform(canvas.width/W,0,0,canvas.height/H,0,0);ctx.imageSmoothingEnabled=false}
addEventListener("resize",resize);resize();
function beep(freq=600,dur=.08,type="square",vol=.035){if(muted)return;try{audioCtx ||= new (window.AudioContext||window.webkitAudioContext)();let o=audioCtx.createOscillator(),g=audioCtx.createGain();o.type=type;o.frequency.value=freq;g.gain.value=vol;o.connect(g);g.connect(audioCtx.destination);o.start();g.gain.exponentialRampToValueAtTime(.001,audioCtx.currentTime+dur);o.stop(audioCtx.currentTime+dur)}catch(e){}}
function say(t){const el=document.getElementById("toast");el.textContent=t;el.classList.add("show");toastTimer=110}
const rect=(x,y,w,h)=>({x,y,w,h});
const hit=(a,b)=>a.x<b.x+b.w&&a.x+a.w>b.x&&a.y<b.y+b.h&&a.y+a.h>b.y;
function makeLevel(i){
 const world=Math.floor(i/2),local=i%2,width=3100+(local*300),plats=[rect(0,GROUND,width,150)],items=[],enemies=[];
 // Designed platforms and gaps, with a few alternate high routes.
 for(let x=260,n=0;x<width-260;x+=330,n++){
   const y=[355,320,375,300][n%4];
   plats.push(rect(x,y,125,20));
   items.push({r:rect(x+48,y-35,18,20),type:"coin",got:false});
   if(n%3===1)items.push({r:rect(x+88,y-62,22,22),type:"secret",got:false});
   if(n%4===2)items.push({r:rect(x+30,y-86,20,20),type:"star",got:false});
 }
 // gaps in ground; floating platforms bridge some of them
 for(let x=700;x<width-300;x+=900){plats[0]&&null; // visual/gameplay ground cutouts below
   plats.push(rect(x+180,GROUND-88,130,18));
 }
 const gaps=[];for(let x=700;x<width-300;x+=900)gaps.push({x:x+35,w:115});
 for(let x=430;x<width-300;x+=520)enemies.push({r:rect(x,GROUND-34,34,34),min:x-70,max:x+170,v:1.15,hp:1,boss:false,alive:true});
 const boss=local===1?{r:rect(width-500,GROUND-58,58,58),min:width-690,max:width-250,v:1.35,hp:4,boss:true,alive:true}:null;
 return {world,local,width,plats,items,enemies,boss,gaps,checkpoint:Math.floor(width/2),saved:false,goal:width-100};
}
function start(i,fresh=false){levelIndex=Math.max(0,Math.min(9,i));level=makeLevel(levelIndex);player={x:70,y:GROUND-48,w:30,h:44,vx:0,vy:0,jumps:0,face:1,inv:0,power:0};camera=0;if(fresh){lives=3;score=0;coins=0}state="play"}
function hurt(){if(player.inv>0)return;lives--;beep(180,.18,"sawtooth");if(lives<=0){state="over";return}player.x=level.saved?level.checkpoint+20:70;player.y=GROUND-48;player.vx=player.vy=0;player.inv=100}
function movePlayer(){
 let ax=keys.left?-1:keys.right?1:0;player.vx+=ax*.72;if(!ax)player.vx*=.78;player.vx=Math.max(-5,Math.min(5,player.vx));if(level.world===2&&player.y+player.h>=GROUND-1)player.vx*=.985;
 player.x+=player.vx;
 for(const p of level.plats){if(hit(player,p)){if(player.vx>0)player.x=p.x-player.w;if(player.vx<0)player.x=p.x+p.w;player.vx=0}}
 player.vy=Math.min(player.vy+.52,12);player.y+=player.vy;let on=false;
 for(const p of level.plats){if(hit(player,p)){if(player.vy>0){player.y=p.y-player.h;on=true;player.jumps=0}else if(player.vy<0)player.y=p.y+p.h;player.vy=0}}
 // ground gaps
 if(player.y+player.h>=GROUND && !level.gaps.some(g=>player.x+player.w>g.x&&player.x<g.x+g.w)){player.y=GROUND-player.h;player.vy=0;player.jumps=0;on=true}
 if(player.inv)player.inv--;if(player.power)player.power--;
 if(player.y>H+90)hurt();
}
function jump(){if(state!=="play")return;if(player.jumps<2){player.vy=player.jumps===0?-10.7:-9.5;player.jumps++;beep(player.jumps===1?510:740,.08);}}
function update(){
 if(state!=="play")return;
 movePlayer();
 for(const it of level.items){if(!it.got&&hit(player,it.r)){it.got=true;if(it.type==="coin"){coins++;score+=10;beep(850,.05)}else if(it.type==="star"){score+=100;player.power=420;say("¡ESTRELLA! Poder temporal");beep(1000,.2)}else{score+=150;lives=Math.min(3,lives+1);say("¡BLOQUE SECRETO! +1 vida");beep(900,.15)}}}
 if(!level.saved&&player.x>level.checkpoint){level.saved=true;say("PUNTO DE GUARDADO");beep(700,.15)}
 const foes=[...level.enemies,...(level.boss?[level.boss]:[])];
 for(const e of foes){if(!e.alive)continue;e.r.x+=e.v;if(e.r.x<e.min||e.r.x+e.r.w>e.max)e.v*=-1;
   if(hit(player,e.r)){if(player.vy>0&&player.y+player.h-e.r.y<24){e.hp--;player.vy=-8.7;beep(300,.07);if(e.hp<=0){e.alive=false;score+=e.boss?600:50;say(e.boss?"¡JEFE DERROTADO!":"¡Buen salto!")} }else hurt()}
 }
 if(player.x+player.w>level.goal){
   if(level.boss&&level.boss.alive){player.x=level.goal-player.w-5;say("¡Derrota al jefe para abrir la salida!")}
   else{score+=250;unlocked=Math.max(unlocked,levelIndex+1);localStorage.setItem("sdaUnlocked",unlocked);if(levelIndex===9)state="victory";else start(levelIndex+1)}
 }
 camera=Math.max(0,Math.min(player.x-W*.42,level.width-W));if(toastTimer>0&&!--toastTimer)document.getElementById("toast").classList.remove("show");
}
function drawText(t,x,y,size=22,color="#fff",align="left"){ctx.font=`bold ${size}px system-ui, sans-serif`;ctx.textAlign=align;ctx.lineWidth=4;ctx.strokeStyle="#17213a";ctx.strokeText(t,x,y);ctx.fillStyle=color;ctx.fillText(t,x,y)}
function pixelRect(x,y,w,h,c){ctx.fillStyle=c;ctx.fillRect(Math.round(x),Math.round(y),w,h)}
function background(){
 const w=level.world;ctx.fillStyle=skies[w];ctx.fillRect(0,0,W,H);
 for(let i=0;i<8;i++){let x=(i*190-camera*.25)%(W+220)-100;
   if(w===1){ctx.fillStyle="#df9f59";ctx.beginPath();ctx.moveTo(x,450);ctx.lineTo(x+100,235);ctx.lineTo(x+210,450);ctx.fill()}
   else if(w===2){ctx.fillStyle="#e4f5fa";ctx.beginPath();ctx.moveTo(x,450);ctx.lineTo(x+105,200);ctx.lineTo(x+215,450);ctx.fill()}
   else if(w>=3){pixelRect(x+30,155,90,295,"#292641");ctx.fillStyle="#292641";ctx.beginPath();ctx.moveTo(x+15,165);ctx.lineTo(x+75,80);ctx.lineTo(x+135,165);ctx.fill()}
   else{ctx.fillStyle="#54a76a";ctx.beginPath();ctx.arc(x+95,365,95,Math.PI,0);ctx.fill()}
 }
 if(w===0){for(let i=0;i<5;i++){let x=(i*250-camera*.12)%(W+100);ctx.fillStyle="#f4fbff";ctx.beginPath();ctx.ellipse(x,95+i%2*30,50,14,0,0,Math.PI*2);ctx.fill()}}
}
function drawPlayer(){let x=player.x-camera,y=player.y;if(player.inv&&player.inv%8<4)return;
 pixelRect(x+4,y+15,22,25,"#3269a3");pixelRect(x+6,y+2,18,16,"#f0bd8b");pixelRect(x+3,y,24,8,"#27a89a");pixelRect(x+2,y+17,26,5,"#ed7448");pixelRect(x+4,y+38,10,6,"#29334c");pixelRect(x+18,y+38,10,6,"#29334c");pixelRect(x+(player.face>0?20:8),y+8,3,4,"#18233a");
}
function draw(){
 if(state==="play"||state==="pause"){
   background();
   for(const p of level.plats){let x=p.x-camera;if(x+p.w<0||x>W)continue;pixelRect(x,p.y,p.w,p.h,grounds[level.world]);pixelRect(x,p.y,p.w,7,accents[level.world]);if(p.y<GROUND)for(let xx=x+8;xx<x+p.w;xx+=24)pixelRect(xx,p.y+10,10,5,"#334052")}
   for(const g of level.gaps)pixelRect(g.x-camera,GROUND, g.w,100,"#17213a");
   for(const it of level.items){if(it.got)continue;let x=it.r.x-camera;let c=it.type==="coin"?"#ffd33d":it.type==="star"?"#fff18a":"#d58bff";pixelRect(x,it.r.y,it.r.w,it.r.h,c);pixelRect(x+4,it.r.y+3,4,7,"#fffbd7")}
   // checkpoint
   let cx=level.checkpoint-camera;pixelRect(cx,345,5,105,"#574b45");ctx.fillStyle=level.saved?"#59e79d":"#e7e7e7";ctx.beginPath();ctx.moveTo(cx+5,348);ctx.lineTo(cx+47,362);ctx.lineTo(cx+5,380);ctx.fill();
   pixelRect(level.goal-camera,300,7,150,"#f2dc88");ctx.fillStyle="#ff8054";ctx.beginPath();ctx.moveTo(level.goal-camera+7,300);ctx.lineTo(level.goal-camera+63,320);ctx.lineTo(level.goal-camera+7,345);ctx.fill();
   for(const e of [...level.enemies,...(level.boss?[level.boss]:[])])if(e.alive){let x=e.r.x-camera,y=e.r.y;pixelRect(x,y,e.r.w,e.r.h,e.boss?"#f4c94f":"#b84d60");pixelRect(x+7,y+10,5,5,"#382b3b");pixelRect(x+e.r.w-12,y+10,5,5,"#382b3b");if(e.boss)drawText("JEFE "+e.hp,x+e.r.w/2,y-8,13,"#fff","center")}
   drawPlayer();
   pixelRect(0,0,W,43,"#17213a");drawText("VIDAS "+lives,16,28,17,"#ff9999");drawText("MONEDAS "+coins,150,28,17,"#ffe27b");drawText("PUNTOS "+score,320,28,17);drawText(WORLDS[level.world]+" · NIVEL "+(level.local+1),W-18,28,16,"#c5efff","right");
   if(state==="pause"){ctx.fillStyle="#0009";ctx.fillRect(0,0,W,H);drawText("PAUSA",W/2,230,52,"#fff","center");drawText("Toca Ⅱ para continuar · M para menú",W/2,285,20,"#ffe27b","center")}
 }else{
   ctx.fillStyle=state==="menu"?"#1c2b4c":state==="select"?"#171d36":state==="victory"?"#23504d":"#321d35";ctx.fillRect(0,0,W,H);
   if(state==="menu"){drawText("SUPER DILAN",W/2,170,58,"#ffe178","center");drawText("ADVENTURE",W/2,230,52,"#73e5c3","center");drawText("Una aventura pixelada de mundos y secretos",W/2,290,20,"#fff","center");drawText("TOCA JUGAR",W/2,370,28,"#ffe178","center");drawText("Controles táctiles · Doble salto · 5 mundos",W/2,430,17,"#dceaff","center")}
   if(state==="select"){drawText("SELECCIÓN DE NIVELES",W/2,65,36,"#ffe178","center");for(let i=0;i<10;i++){let x=155+(i%2)*335,y=110+Math.floor(i/2)*70,ok=i<=unlocked;ctx.fillStyle=ok?"#67d49e":"#62677a";ctx.fillRect(x,y,290,50);drawText((i+1)+". "+WORLDS[Math.floor(i/2)]+" "+(i%2+1),x+145,y+32,16,"#14213a","center")}drawText("Toca un nivel desbloqueado · M para volver",W/2,500,17,"#fff","center")}
   if(state==="over"){drawText("FIN DE LA PARTIDA",W/2,220,48,"#ff9696","center");drawText("TOCA REINTENTAR o MENÚ",W/2,310,22,"#fff","center")}
   if(state==="victory"){drawText("¡AVENTURA COMPLETADA!",W/2,220,42,"#ffe178","center");drawText("Puntuación final: "+score,W/2,290,24,"#fff","center");drawText("¡Dilan salvó los cinco mundos!",W/2,350,22,"#a5f1d9","center")}
 }
}
function frame(){if(state==="play"){if(keys.jump&&!lastJump)jump();lastJump=keys.jump;update()}else lastJump=keys.jump;draw();requestAnimationFrame(frame)}
function canvasPoint(e){let r=canvas.getBoundingClientRect();return{x:(e.clientX-r.left)*W/r.width,y:(e.clientY-r.top)*H/r.height}}
canvas.addEventListener("pointerdown",e=>{e.preventDefault();if(audioCtx&&audioCtx.state==="suspended")audioCtx.resume();let p=canvasPoint(e);
 if(state==="menu"){if(p.y>300){if(p.x>W*.65)state="select";else start(0,true)}}
 else if(state==="select"){if(p.y<85){state="menu"}else{let col=p.x<480?0:1,row=Math.floor((p.y-110)/70),idx=row*2+col;if(idx>=0&&idx<10&&idx<=unlocked)start(idx,true);else if(p.y>470)state="menu"}}
 else if(state==="pause"){if(p.y>260){state="play"}}
 else if(state==="over"||state==="victory"){if(p.y>285&&p.x>W*.58)state="menu";else start(0,true)}
});
function bindHold(id,key){const el=document.getElementById(id);const on=e=>{e.preventDefault();keys[key]=true;el.classList.add("active");if(audioCtx&&audioCtx.state==="suspended")audioCtx.resume()};const off=e=>{e.preventDefault();keys[key]=false;el.classList.remove("active")};el.addEventListener("pointerdown",on);["pointerup","pointercancel","pointerleave"].forEach(ev=>el.addEventListener(ev,off))}
bindHold("leftBtn","left");bindHold("rightBtn","right");bindHold("jumpBtn","jump");
document.getElementById("pauseBtn").addEventListener("pointerdown",e=>{e.preventDefault();if(state==="play")state="pause";else if(state==="pause")state="play";else if(state==="menu")state="select";else state="menu";});
addEventListener("keydown",e=>{if(["ArrowLeft","ArrowRight","ArrowUp"," ","Escape"].includes(e.key))e.preventDefault();if(e.key==="ArrowLeft"||e.key==="a")keys.left=true;if(e.key==="ArrowRight"||e.key==="d")keys.right=true;if([" ","ArrowUp","w"].includes(e.key))keys.jump=true;if(e.key==="Escape"||e.key==="p"){if(state==="play")state="pause";else if(state==="pause")state="play"}if(e.key==="Enter"){if(state==="menu")start(0,true);else if(state==="over"||state==="victory")start(0,true)}if(e.key==="l"&&state==="menu")state="select";if(e.key==="m"){if(state==="pause"||state==="over"||state==="victory")state="menu"}});
addEventListener("keyup",e=>{if(e.key==="ArrowLeft"||e.key==="a")keys.left=false;if(e.key==="ArrowRight"||e.key==="d")keys.right=false;if([" ","ArrowUp","w"].includes(e.key))keys.jump=false});
document.addEventListener("visibilitychange",()=>{if(document.hidden&&state==="play")state="pause"});
if("serviceWorker" in navigator && location.protocol!=="file:"){window.addEventListener("load",()=>navigator.serviceWorker.register("./sw.js").catch(()=>{}))}
frame();
})();